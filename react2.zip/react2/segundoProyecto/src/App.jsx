import { useState } from 'react'
import './App.css'
import MensajeBienvenida from './MensajeBienvenida'
import EstadoCuenta from './EstadoCuenta'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <div>
        <MensajeBienvenida isLogado={true}></MensajeBienvenida >
        <EstadoCuenta isPositive={true}></EstadoCuenta >

      </div>
    </>
  )
}

export default App
