export default function MensajeBienvenida({ isLogado }) {

    if(isLogado=true){
        return ('wferfer');

    }
    }
