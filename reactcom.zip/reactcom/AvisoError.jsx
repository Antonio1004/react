export default function AvisoError({ hasError }) {
        if(hasError=true){
            return ('error');
    
        }
    }