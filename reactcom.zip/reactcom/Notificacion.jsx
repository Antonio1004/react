/**
 * Los volúmenes son gestionados por Docker y almacenan datos en una ubicación especial, mientras que los bind 
 *  mounts usan directorios específicos del host. Los volúmenes son más flexibles para compartir datos entre contenedores.
 */